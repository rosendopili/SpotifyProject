package com.example.springbootmonolith;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMonolithApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMonolithApplication.class, args);
	}

}
